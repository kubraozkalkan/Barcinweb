﻿using Microsoft.AspNetCore.Mvc;

namespace BARÇIN_WEB_SİTESİ.Controllers
{
    public class HomeController:Controller
    {

        public IActionResult Index()
        {
            return View();
        }
    }
}
